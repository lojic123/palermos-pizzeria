PALERMO'S PIZZERIA — VERSION 2
=================================

Included:
- Premium responsive home page
- Separate full menu page
- Animated pizza/typography treatment
- Real food photography sourced from Unsplash for the visual mockup
- Mobile sticky call/menu bar
- Menu category tabs
- Call-to-order buttons
- Directions button
- Facebook button
- Current restaurant details and hours from public listings

IMPORTANT PHOTO NOTE:
The photography in this mockup is professional food photography, but it is NOT represented as Palermo's own photography. The public Hummelstown listings expose photos but not stable direct image URLs suitable for bundling here. Replace the Unsplash image URLs in index.html with Palermo's official/owner-provided photos before publishing.

IMPORTANT ORDERING NOTE:
Public listings confirm takeout/delivery and show an "Order Online" option, but I could not verify a stable direct online-ordering URL for the Hummelstown location. For safety, the site's order CTAs currently call (717) 566-0668 instead of sending customers to an unverified third-party ordering page. Once the restaurant's actual ordering URL is known, replace the phone links with it.

Source details checked:
- 103 E Main St, Hummelstown, PA 17036
- (717) 566-0668
- Takeout/delivery
- Tue-Sat 10:30 AM-10 PM; Sun 10:30 AM-9 PM; Monday closed
- Public listings describe Palermo's as family-run and highlight pizza, pasta, Stromboli, Buffalo chicken sub, garlic knots and other favorites.
