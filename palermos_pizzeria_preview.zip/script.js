const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
const data={
 pizza:[["Pepperoni Pizza","Classic Palermo's favorite."],["Buffalo Chicken Pizza","Bold buffalo chicken flavor."],["Sicilian Pizza","Thick, square and hearty."],["Chicken Alfredo Stuffed Pizza","A signature stuffed favorite."]],
 pasta:[["Chicken & Broccoli Alfredo","Creamy Alfredo comfort food."],["Spaghetti Marinara","Classic red-sauce pasta."],["Penne with Vodka Sauce","Rich tomato-cream sauce."],["Linguine & Clams","A seafood favorite."]],
 subs:[["Italian Sub","Classic Italian-style sandwich."],["Cheesesteak","Made to order."],["Buffalo Chicken Sub","A customer favorite."],["Chicken Parm Sandwich","A Palermo's standout."]],
 more:[["Garlic Knots","Served with marinara."],["Buffalo Wings","Ask about today's flavors."],["Chicken Fingers & Fries","Family-friendly favorite."],["Bacon Cheddar Fries","Loaded comfort-food side."]]
};
const box=document.getElementById("quickMenu");
if(box){
 const render=(cat)=>{box.innerHTML=data[cat].map(x=>`<article class="quick-item"><div><h3>${x[0]}</h3><p>${x[1]}</p></div><b>CALL FOR PRICE</b></article>`).join("")};
 render("pizza");
 document.querySelectorAll(".menu-tabs button").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".menu-tabs button").forEach(b=>b.classList.remove("active"));btn.classList.add("active");render(btn.dataset.cat)}));
}
